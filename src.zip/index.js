import './styles.scss';
import postTpl from './tpl/post.handlebars';

const baseUrl = 'http://3e9e02f4ed06.ngrok.io';

const getDataServer = (path) => fetch(`${baseUrl}${path}`).then(res => res.json());

const uploadDataServer = (path, data) => {
    const option = {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
            "Content-Type": "application/json; charset=UTF-8"
        }
    };
    return fetch(`${baseUrl}${path}`, option).then(res => res.json());
};

const printPosts = async () => {
    const posts = await getDataServer('/posts');
    const comments = await getDataServer('/comments');

    posts.sort((a, b) => b.id - a.id);

    posts.forEach((post, index) => {
        posts[index].comments = comments.filter(item => item.postId === post.id);
    });

    document.querySelector('#posts').insertAdjacentHTML('beforeend', postTpl(posts));
};

document.querySelector('form.create-post').addEventListener('keyup', async (e) => {
    if (e.code !== 'Enter') return false;

    const data = {};
    e.currentTarget.querySelectorAll('input, textarea').forEach(el => {
        data[el.getAttribute('name')] = el.value;
        el.value = '';
    });

    const res = await uploadDataServer('/posts', data);

    document.querySelector('#posts').insertAdjacentHTML('afterbegin', postTpl([res]));
});

document.querySelector('#posts').addEventListener('keyup', async (e) => {
    if (e.code !== 'Enter') return false;
    const postNode = e.target.parentNode;

    const postId = +postNode.dataset.id;
    const text = e.target.value;

    e.target.value = '';
    
    uploadDataServer('/comments', {postId, body: text});

    postNode.querySelector('.comments').insertAdjacentHTML('afterbegin', `<div class="comment"><p>${text}</p></div>`);
});

printPosts();